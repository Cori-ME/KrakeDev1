calcularValorTotal = function () {
  //variables para recuperar los valores de las cajas de texto
  let nombreProducto;

  nombreProducto = recuperarTexto("txtProducto");

  let precioProducto; // SE UTILIZA PARA RECUPERAR EL PRECIO COMO FLOAT
  precioProducto = recuperarFloat("txtPrecio");

  let cantidad; // SE UTILIZA PARA RECUPERAR LA CANTIDAD COMO INT
  cantidad = recuperarInt("txtCantidad");

  let valorSubtotal = calcularSubtotal(precioProducto, cantidad);

  mostrarTexto("lblSubtotal", valorSubtotal);

  let valorDescuento = calcularDesPorVolumen(valorSubtotal, cantidad);

  //7. Mostrar el resultado en el componente lblDescuento
  mostrarTexto("lblDescuento", valorDescuento);

  let resultadoIVA;
  resultadoIVA = valorSubtotal - valorDescuento;

  let valorIVA = calcularIva(resultadoIVA);

  // El IVA debe calcularse sobre el valor del subtotal menos el descuento
  //9. Mostrar el resultado en el componente lblValorIVA
  mostrarTexto("lblValorIVA", valorIVA);

  let valorTotal = calcularTotal(valorSubtotal, valorDescuento, valorIVA);

  //11. Mostrar el resultado en el componente lblTotal

  mostrarTexto("lblTotal", valorTotal);

  mostrarTexto(
    "lblResumen",
    "El valor a pagar por " +
      cantidad +
      "  " +
      nombreProducto +
      " con descuento de" +
      valorDescuento +
      ": UDS " +
      valorTotal
  );
};
limpiar = function () {
  /*
      Dejar todas las cajas de texto con el valor cadena vacía, 0 ó 0.0 según el tipo de dato
      Dejar todos los textos de los montos con el valor 0.0
      Si funciona, hacer un commit
   */

  mostrarTextoEnCaja("txtProducto", "");
  mostrarTextoEnCaja("txtPrecio", "0.0");
  mostrarTextoEnCaja("txtCantidad", "0");
};
/* SI TODO FUNCIONA, HACER UN PUSH */
