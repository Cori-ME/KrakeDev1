calcularValorDescuento = function (monto, porcentajeDescuento) {
  let valorDescuento;
  valorDescuento = (monto * porcentajeDescuento) / 100;

  return valorDescuento;
}

calcularDesPorVolumen = function (subtotal, valorCantidad) {
  let nombreProducto=recuperarTexto("txtProducto");
  let precioProducto=recuperarInt("txtPrecio");
  let cantidad=recuperarInt("txtCantidad");
  
  let descuento;
  if (valorCantidad < 3) {
    descuento = "NO TIENE DESCUENTO";
  } else if (valorCantidad >= 3 && valorCantidad <= 5) {
    descuento = "TIENE DESCUENTO DE:" + subtotal * 0.03;
  } else if (valorCantidad >= 6 && valorCantidad <= 11) {
    descuento = "TIENE DESCUENTO DE:" + subtotal * 0.04;
  } else if (valorCantidad >= 12) {
    descuento = "TIENE DESCUENTO DE:" + subtotal * 0.05;
  }
  if (
    esProductoValido(nombreProducto, "lblProducto") &&
    esPrecioValido(precioProducto, "lblPrecio") &&
    esCantidadValida(cantidad, "lblCantidad")
  ) {
    // solo si todo esta bien  muestra el resultado
    descuento = calcularDesPorVolumen(
      nombreProducto,
      precioProducto,
      cantidad
    );
    descuento = descuento.toFixed(2);
    mostrarTexto("lblTotal", descuento);
  } else {
    mostrarTexto("lblTotal", "0.0");
  }
  return descuento;
};

esProductoValido = function (nombreProducto, idComponenteError) {
  let hayErrores = false;
  if (nombreProducto == "") {
    mostrarTexto(idComponenteError, "CAMPO OBLIGATORIO");
    hayErrores = true;
  }


      console.log("punto de venta"+nombreProducto);
  if (nombreProducto.lenght>10) {
    
    mostrarTexto(
      idComponenteError,
      "EL NOMBRE DEL PRODUCTO NO PUEDE TENER MAS DE 10 CARACTERES"
    );
    hayErrores = true;
  }
  if (hayErrores == false) {
    mostrarTexto(idComponenteError, "");
  }
  return !hayErrores;
};
esPrecioValido = function (precioProducto, idComponenteError) {
  let hayErrores = false;
  if (precioProducto == "") {
    mostrarTexto(idComponenteError, "CAMPO OBLIGATORIO");
    hayErrores = true;
  }
  
  if (precioProducto > 0 || precioProducto < 50) {
    mostrarTexto(idComponenteError, "EL PRECIO DEBE SER ENTRE 0 Y 50");
    hayErrores = true;
  }
  if (hayErrores == false) {
    mostrarTexto(idComponenteError, "");
  }
  return !hayErrores;
};
esCantidadValida = function (cantidad, idComponenteError) {
  let hayErrores = false;
  if (cantidad == "") {
    mostrarTexto(idComponenteError, "CAMPO OBLIGATORIO");
    hayErrores = true;
  }
  
  if (cantidad > 0 && cantidad < 100) {
    mostrarTexto(
      idComponenteError,
      "LA CANTIDA DEBE SER UN NUMERO ENTRE 0 Y 100"
    );
    hayErrores = true;
  }
  if (hayErrores == false) {
    mostrarTexto(idComponenteError, "");
  }
  return !hayErrores;
};
calcularIva = function (monto) {
  let valorIVA;

  valorIVA = (monto * 12) / 100;

  return parseFloat(valorIVA.toFixed(4));
};
calcularSubtotal = function (precio, cantidad) {
  let valorTotalPagar;

  valorTotalPagar = precio * cantidad;

  return valorTotalPagar;
};

calcularTotal = function (subtotal, descuento, iva) {
  let totalPagar;
  totalPagar = subtotal - descuento + iva;
  return totalPagar;
};
